function [model] = random_krr_train(trainX,trainy,opts)
% [model] = random_krr_train(trainX, trainy, opts)
%
% Arguments:
% trainX		       input data, an n by d sparse matrix, each row is a data point. 
% trainy			   the target, an n by 1 vector
% opts.gamma   the kernel width in RBF kernel(default 1/n)
% opts.noc	   number of clusters(default 10) 
% opts.lambda  the regularization term (default 1/n)
% opts.cluster	clustering method (0: kmeans, 1: kernel kmeans, default 0)
% opts.kernel	the kernel used (0:rbf, 1:poly, default 0)
[n,d] = size(trainX);
if ~isfield(opts,'noc'),
	opts.noc = 10;
end
if ~isfield(opts,'lambda'),
	opts.lambda = 1/n;
end
if ~isfield(opts,'gamma'),
	opts.gamma = 1/n;
end
if ~isfield(opts,'kernel'),
	opts.kernel = 0;
end
if ~isfield(opts,'cluster'),
	opts.cluster = 0;
end
if ~isfield(opts,'degree'),
	opts.degree = 2;
end

k = opts.noc;
lambda = opts.lambda;
gamma = opts.gamma;
method = opts.cluster;
kernel = opts.kernel;
degree = opts.degree;
fprintf('***************************\n');
fprintf('Parameters ...\n');
fprintf('# of training data points %d, # of dimension %d,\n# of clusters = %d, cluster type = %d(1:kmeans,0:kernel kmeans), lambda = %f \n kernel type = %d(1: rbf, 0:poly), gamma= %f, degree = %d\n',n, d, opts.noc, opts.cluster, opts.lambda, opts.kernel, opts.gamma, opts.degree);
fprintf('***************************\n');
display('Begin random dckrr train!');

idx = ceil(rand(1,n)*k);
for i = 1:k,
	fprintf('working on %d cluster\n',i);
	ind = find(idx==i);
	Xsub = trainX(ind,:);
	ysub = trainy(ind);
	tt = numel(ind);
	if kernel==1,
		Ktrain = rbf(Xsub,Xsub,gamma); % form the gaussian kernel
	elseif kernel==0,
		Ktrain= poly(Xsub,Xsub, gamma, degree );
	end
	lambda = 1/numel(ysub);
	alphalist{i} = inv(Ktrain+lambda*eye(tt))*ysub;% compute alpha for 
end
model.alpha = alphalist;
model.idx = idx;
model.gamma = gamma;
model.degree = degree;
model.noc = k;
model.kernel = kernel;
