function [Xtrain,Xtest] = normal_X(Xtrain,Xtest)

X = [Xtrain;Xtest];
l = size(X,1);
ll = size(Xtrain,1);
X_mean = mean(X);
X_std = std(X);
ind = find(X_std==0);
X_std(ind) = 1;
X = (X-ones(l,1)*X_mean)./(ones(l,1)*X_std);

Xtrain = X(1:ll,:); 
Xtest = X(ll+1:end,:); 
%
