function gamma =krr_choose_gamma(trainX,testX,yTrain,yTest,opts) 
lambda = opts.lambda;
kernel = opts.kernel;
degree = opts.degree;
[n,d] = size(trainX);
idx = randperm(n);
m = 5000;
if n>m
	trainX = trainX(idx(1:m),:);
	yTrain = yTrain(idx(1:m));
	n = m;
end
gammalist = [0.0001, 0.001,0.01,0.1,1,10,100];
test_rmse = [];
for ig = 1:numel(gammalist),
	gamma = gammalist(ig)
	if kernel==1,
		Ktrain = rbf(trainX,trainX,gamma); % form the gaussian kernel
	elseif kernel==0,
		Ktrain= poly(trainX,trainX, gamma, degree );
	end	
	alpha = inv(Ktrain+lambda*eye(n))*yTrain;

	ypred = zeros(size(yTest));
	if kernel == 1,
		ypred  = exp(-sqdist(testX,trainX)*gamma)*alpha;
	elseif kernel ==0,
		tt = poly(testX,trainX,gamma,degree);
		ypred = tt*alpha;
	end
	test_rmse(ig) = sqrt(sum((yTest-ypred).^2)/numel(yTest))
end

gamma = gammalist(find(test_rmse ==min(test_rmse)))
