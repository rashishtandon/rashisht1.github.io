function [ypred] = random_krr_test(xTest,xTrain,model)
% [ypred] =random_krr_test(xTest,xTrain,model)
%
% Arguments:
% xTest		       input testing data, an n_1 by d sparse matrix, each row is a data point. 
% model       	   model trained from dckrr_train.m
% ypred	  		   prediction for xTesti, a n_1 by 1 vector
%
display('Begin dckrr test!');
alpha = model.alpha;
gamma = model.gamma;
degree = model.degree;
idx = model.idx;
noc = numel(alpha);
n = size(xTest,1);

ypred = zeros(n,1);
for i = 1:noc,
	Asub = xTrain(idx==i,:);
	if model.kernel == 1,
		ypred  = ypred+exp(-sqdist(xTest,Asub)*gamma)*alpha{i};
	elseif model.kernel ==0,
		tt = poly(xTest,Asub,gamma,degree);
		ypred = ypred+tt*alpha{i};
	end
end
ypred = ypred/noc;
