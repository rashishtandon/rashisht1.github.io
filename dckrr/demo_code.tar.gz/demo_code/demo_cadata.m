clear all;
maxNumCompThreads(1);
load 'cadata_scale.mat';% the best gamma=0.1
rand('seed',0);
iid = randperm(size(X,1));
cut = floor(0.8*numel(iid));
xTrain = X(iid(1:cut),:); % training data
yTrain = y(iid(1:cut)); % training label
xTest = X(iid(cut+1:end),:); %testing data
yTest = y(iid(cut+1:end)); % testing label
%{
[xTrain, xTest] = normal_X(xTrain,xTest);
[n,d] = size(xTrain);
[n,T] = size(yTrain);
Ntest = size(yTest,1);
meany = mean(yTrain);
xTrain = sparse(xTrain);
xTest = sparse(xTest);
yTrain = yTrain-ones(size(yTrain))*meany;
yTest = yTest-ones(size(yTest))*meany;
%}
opts = []; 
%opts.noc = 10; % number of clusters
opts.lambda = 1/cut; % regularization term in krr
opts.gamma = 0.1; % gaussian width/bias term in poly
opts.cluster = 1; % 1: kmeans; 0: kernel kmeans
opts.kernel = 1; % 1: rbf; 0: poly
opts.degree = 2; % degree in poly
t = cputime;
SampleSize = [2000:2000:12000];
klist = 2.^[2:2:8]
%SampleSize = [1000,5000];
%klist = [2:2:6]
iid = randperm(cut);
%gamma = krr_choose_gamma(xTrain,xTest,yTrain,yTest,opts);
for isamp = 1:numel(SampleSize),
	nl = SampleSize(isamp)
%	iid = randperm(cut);
	xTraintmp = xTrain(iid(1:nl),:);
	yTraintmp = yTrain(iid(1:nl));
	opts.lambda = 1/nl;

	opts.noc = 1;
	timestart = cputime;
	model_random = random_krr_train_under_reg(xTraintmp,yTraintmp,opts);
	whole_time_train(isamp) = cputime - timestart;
		
	timestart = cputime;
	ypred_random = random_krr_test(xTest,xTraintmp,model_random);
	whole_time_test(isamp) = cputime-timestart;
	whole_test_rmse(isamp) = sqrt(sum((yTest-ypred_random).^2)/numel(yTest));
	

	for ik = 1:numel(klist),
		opts.noc = klist(ik)
		timestart = cputime;
		model = dckrr_train_under_reg(xTraintmp,yTraintmp,opts);
		cluster_time_train_under_reg(isamp,ik) = cputime - timestart;

		timestart = cputime;
		ypred = dckrr_test(xTest,xTraintmp,model);
		cluster_time_test_under_reg(isamp,ik) = cputime-timestart;
		cluster_test_rmse_under_reg(isamp,ik) = sqrt(sum((yTest-ypred).^2)/numel(yTest));

		timestart = cputime;
		model_random = random_krr_train_under_reg(xTraintmp,yTraintmp,opts);
		random_time_train_under_reg(isamp,ik) = cputime - timestart;
		
		timestart = cputime;
		ypred_random = random_krr_test(xTest,xTraintmp,model_random);
		random_time_test_under_reg(isamp,ik) = cputime-timestart;
		random_test_rmse_under_reg(isamp,ik) = sqrt(sum((yTest-ypred_random).^2)/numel(yTest));
	
	end

	for ik = 1:numel(klist),
		opts.noc = klist(ik)
		timestart = cputime;
		model = dckrr_train(xTraintmp,yTraintmp,opts);
		cluster_time_train(isamp,ik) = cputime - timestart;

		timestart = cputime;
		ypred = dckrr_test(xTest,xTraintmp,model);
		cluster_time_test(isamp,ik) = cputime-timestart;
		cluster_test_rmse(isamp,ik) = sqrt(sum((yTest-ypred).^2)/numel(yTest));

		timestart = cputime;
		model_random = random_krr_train(xTraintmp,yTraintmp,opts);
		random_time_train(isamp,ik) = cputime - timestart;
		
		timestart = cputime;
		ypred_random = random_krr_test(xTest,xTraintmp,model_random);
		random_time_test(isamp,ik) = cputime-timestart;
		random_test_rmse(isamp,ik) = sqrt(sum((yTest-ypred_random).^2)/numel(yTest));
	
	end

end

save cadata_diffm SampleSize klist random_time_test cluster_time_test random_time_test_under_reg cluster_time_test_under_reg random_time_train cluster_time_train random_time_train_under_reg cluster_time_train_under_reg random_test_rmse cluster_test_rmse random_test_rmse_under_reg cluster_test_rmse_under_reg whole_time_test whole_time_train whole_test_rmse

