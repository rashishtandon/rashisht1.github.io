function [model] = dckrr_train(trainX,trainy,opts)
% [model] = dckrr_train(trainX, trainy, opts)
%
% Arguments:
% trainX		       input data, an n by d sparse matrix, each row is a data point. 
% trainy			   the target, an n by 1 vector
% opts.gamma   the kernel width in RBF kernel(default 1/n)
% opts.noc	   number of clusters(default 10) 
% opts.lambda  the regularization term (default 1/n)
% opts.cluster	clustering method (0: kmeans, 1: kernel kmeans, default 0)
% opts.kernel	the kernel used (0:rbf, 1:poly, default 0)
[n,d] = size(trainX);
if ~isfield(opts,'noc'),
	opts.noc = 10;
end
if ~isfield(opts,'lambda'),
	opts.lambda = 1/n;
end
if ~isfield(opts,'gamma'),
	opts.gamma = 1/n;
end
if ~isfield(opts,'kernel'),
	opts.kernel = 0;
end
if ~isfield(opts,'cluster'),
	opts.cluster = 0;
end
if ~isfield(opts,'degree'),
	opts.degree = 2;
end

k = opts.noc;
lambda = opts.lambda;
gamma = opts.gamma;
method = opts.cluster;
kernel = opts.kernel;
degree = opts.degree;
fprintf('***************************\n');
fprintf('Parameters ...\n');
fprintf('# of training data points %d, # of dimension %d,\n# of clusters = %d, cluster type = %d(1:kmeans,0:kernel kmeans), lambda = %f \n kernel type = %d(1: rbf, 0:poly), gamma= %f, degree = %d\n',n, d, opts.noc, opts.cluster, opts.lambda, opts.kernel, opts.gamma, opts.degree);
fprintf('***************************\n');
display('Begin dckrr train!');
%=============== k-means with sampling
if method == 1
	%% modify this number if you want to change number of samples for clustering 
	max_samples_for_cluster = 20000;
	MaxIter = 10;
	num = min(max_samples_for_cluster, n);
	[idx1,centers] = mykmeans(trainX(randsample(n,num),:)',k,MaxIter);
	centers = centers';
	dis = sum(trainX.*trainX,2)*ones(1,k)+ones(n,1)*(sum(centers.*centers,2))'-2*trainX*centers';
	[v idx] = min(dis');
	model.method = 1;
	model.kernel = 1;
	model.centers = centers;
%=============== kernel kmeans with sampling
elseif method ==0 
		%% modify this number if you want to change number of samples for clustering. 
	max_samples_for_cluster = 10000;
	num = min(max_samples_for_cluster, n);
	Xsample = trainX(randsample(n,num), :);
		%% Edit here if you want to add a new kernel
	if kernel==1
		Ksample = rbf(Xsample, Xsample, gamma);
		train_label = knkmeans(Ksample, k, 20);
		idx = knkmeans_rbf_predict(Xsample, trainX, train_label, gamma,  Ksample);
		model.kernel = 1;
		model.gamma = gamma;
	elseif kernel==0
		Ksample = poly(Xsample, Xsample,gamma,degree );
		train_label = knkmeans(Ksample, k, 20);
		idx = knkmeans_poly_predict(Xsample, trainX, train_label, gamma, degree, Ksample);
		model.kernel = 0;
		model.gamma = gamma;
		model.degree = degree;
	end
	model.numcluster = k;
	model.method = 0;
	model.train_label = train_label;
	model.Xsample = Xsample;
	model.Ksample = Ksample;
end

for i = 1:k,
	fprintf('working on %d cluster\n',i);
	ind = find(idx==i);
	Xsub = trainX(ind,:);
	ysub = trainy(ind);
	tt = numel(ind);
	if kernel==1,
		Ktrain = rbf(Xsub,Xsub,gamma); % form the gaussian kernel
	elseif kernel==0,
		Ktrain= poly(Xsub,Xsub, gamma, degree );
	end
	lambda = 1/numel(ysub);
	alphalist{i} = inv(Ktrain+lambda*eye(tt))*ysub;% compute alpha for 
end
model.alpha = alphalist;
model.idx = idx;
model.gamma = gamma;
model.degree = degree;
model.noc = k;
