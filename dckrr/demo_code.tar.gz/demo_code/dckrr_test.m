function [ypred] = dckrr_test(xTest,xTrain,model)
% [ypred] =dckrr_test(xTest, xTrain, model)
%
% Arguments:
% xTest		       input testing data, an n_1 by d sparse matrix, each row is a data point. 
% xTrain		   input training data, an n_2 by d sparse matrix, each row is a data point. 
% model       	   model trained from dckrr_train.m
% ypred	  		   prediction for xTesti, a n_1 by 1 vector
%
display('Begin dckrr test!');
alpha = model.alpha;
gamma = model.gamma;
degree = model.degree;
idx = model.idx;
noc = numel(alpha);
n = size(xTest,1);
if model.method == 1
	k = noc;
	centers = model.centers;
	dis = sum(xTest.*xTest,2)*ones(1,k)+ones(n,1)*(sum(centers.*centers,2))'-2*xTest*centers';
	[v idxtest] = min(dis');
elseif model.method == 0
	k = noc;
	if model.kernel == 1
		idxtest = knkmeans_rbf_predict(model.Xsample, xTest, model.train_label, model.gamma,model.Ksample);
	elseif model.kernel == 0
		idxtest = knkmeans_poly_predict(model.Xsample, xTest, model.train_label, model.gamma,model.degree, model.Ksample);
	end
end

ypred = zeros(n,1);
for i = 1:noc,
	Asub = xTrain(idx==i,:);
	Xtestsub = xTest(idxtest==i,:);
	if model.kernel == 1,
		ypred(idxtest==i)  = exp(-sqdist(Xtestsub,Asub)*gamma)*alpha{i};
	elseif model.kernel ==0,
		tt = poly(Xtestsub,Asub,gamma,degree);
		ypred(idxtest==i)  = tt*alpha{i};
	end
end

