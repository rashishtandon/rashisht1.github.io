from __future__ import print_function
from time import sleep
import sys
import random
import os
sys.path.append('./src/')
from naive import *
from coded import *
from replication import *
from avoidstragg import *
from avoidstragg_nonacc import *
from partial_replication import *
from partial_coded import *
import numpy
from mpi4py import MPI

comm = MPI.COMM_WORLD
rank = comm.Get_rank()
size = comm.Get_size()

if len(sys.argv) != 11:
    print("Usage: python main.py n_procs n_rows n_cols input_dir is_real real_dataset is_coded n_stragglers partial_straggler_partitions coded_ver")
    sys.exit(0)

n_procs, n_rows, n_cols, input_dir, is_real, real_dataset, is_coded, n_stragglers , partitions, coded_ver  = [x for x in sys.argv[1:]]
n_procs, n_rows, n_cols, is_real, is_coded, n_stragglers , partitions, coded_ver = int(n_procs), int(n_rows), int(n_cols), int(is_real), int(is_coded), int(n_stragglers), int(partitions), int(coded_ver)
input_dir = input_dir+"/" if not input_dir[-1] == "/" else input_dir

if not size == n_procs:
    print("Number of processers doesn't match!")
    sys.exit(0)

if is_coded:

    if partitions:
        if(coded_ver == 1):
            if is_real:
                partial_replication_logistic_regression(n_procs, n_rows, n_cols, input_dir + real_dataset +"/partial/" + str((partitions-n_stragglers)*(n_procs-1)) + "/", n_stragglers, partitions, is_real)
            else:
                partial_replication_logistic_regression(n_procs, n_rows, n_cols, input_dir + "artifical-data/" + str(n_rows) + "x" + str(n_cols) +"/partial/", n_stragglers, partitions, is_real)
        elif(coded_ver == 0):
            if is_real:
                partial_coded_logistic_regression(n_procs, n_rows, n_cols, input_dir + real_dataset +"/partial/" + str((partitions-n_stragglers)*(n_procs-1)) + "/", n_stragglers, partitions, is_real)
            else:
                partial_coded_logistic_regression(n_procs, n_rows, n_cols, input_dir + "artifical-data/" + str(n_rows) + "x" + str(n_cols) +"/partial/", n_stragglers, partitions, is_real)

    else:
        if(coded_ver == 0):

            if is_real:
                coded_logistic_regression(n_procs, n_rows, n_cols, input_dir + real_dataset +"/" + str(n_procs-1) + "/", n_stragglers, is_real)
            else:
                coded_logistic_regression(n_procs, n_rows, n_cols, input_dir + "artifical-data/" + str(n_rows) + "x" + str(n_cols) +"/", n_stragglers, is_real)

        elif(coded_ver == 1):

            if is_real:
                replication_logistic_regression(n_procs, n_rows, n_cols, input_dir + real_dataset +"/" + str(n_procs-1) + "/", n_stragglers, is_real)
            else:
                replication_logistic_regression(n_procs, n_rows, n_cols, input_dir + "artifical-data/" + str(n_rows) + "x" + str(n_cols) +"/", n_stragglers, is_real)

        elif(coded_ver ==2):

            if is_real:
                avoidstragg_logistic_regression(n_procs, n_rows, n_cols, input_dir + real_dataset +"/" + str(n_procs-1) + "/", n_stragglers, is_real)
                avoidstragg_nonacc_logistic_regression(n_procs, n_rows, n_cols, input_dir + real_dataset +"/" + str(n_procs-1) + "/", n_stragglers, is_real)
            else:
                avoidstragg_logistic_regression(n_procs, n_rows, n_cols, input_dir + "artifical-data/" + str(n_rows) + "x" + str(n_cols) +"/", n_stragglers, is_real)
                avoidstragg_nonacc_logistic_regression(n_procs, n_rows, n_cols, input_dir + "artifical-data/" + str(n_rows) + "x" + str(n_cols) +"/", n_stragglers, is_real)

else:
    if is_real:
        naive_logistic_regression(n_procs, n_rows, n_cols, input_dir + real_dataset +"/" + str(n_procs-1) + "/", is_real)
    else:
        naive_logistic_regression(n_procs, n_rows, n_cols, input_dir + "artifical-data/" + str(n_rows) + "x" + str(n_cols) +"/", is_real)

comm.Barrier()
MPI.Finalize()