mex -largeArrayDims mykmeans.cpp
