from __future__ import print_function
import sys
import random
import os
import numpy as np
import itertools
from scipy.sparse import csr_matrix

def save_matrix(m, output):
    f = open(output, "w")
    for i in range(len(m)):
        print(" ".join([str(x) for x in m[i]]), file=f)
    f.close()

def save_vector(m, output):
    f = open(output, "w")
    for i in range(len(m)):
        print("%5.3f" %(m[i])+" ", file=f)
    f.close()

# generates a random matrix with each entry chosen independently and uniformly in [0,1]
def generate_random_matrix(n_rows, n_cols):
    return np.random.rand(n_rows, n_cols)

# generates a random matrix representing samples from a two-component GMM with identity covariance
def generate_random_matrix_normal(mu1, mu2, n_rows, n_cols):
    ctrmu2 = np.random.binomial(n_rows,0.5)
    ctrmu1 = n_rows - ctrmu2 
    mfac = 10/np.sqrt(n_cols)
    #mat1 =  #np.random.multivariate_normal(mu1, np.eye(n_cols),ctrmu1) #float(np.random.uniform(low=0, high=100))/100
    #mat2 =  #np.random.multivariate_normal(mu2, np.eye(n_cols),ctrmu2)
    return np.concatenate((np.add(mfac*np.random.standard_normal((ctrmu1, n_cols)), mu1), np.add(mfac*np.random.standard_normal((ctrmu2, n_cols)), mu2)))


def generate_empty_matrix(n_rows, n_cols):
    return np.array([[0 for i in range(n_cols)] for x in range(n_rows)])

# generates a vector of random labels, each entry only has value -1 or 1
def generate_random_label(n):
    return np.array([np.random.randint(2)*2-1 for x in range(n)])

# generates a vector with each entry uniformly and randomly chosen in [0,1]
def generate_random_vector(n):
    return np.array([float(np.random.uniform(low=0, high=100))/100 for x in range(n)])

def save_sparse_csr(filename,array):
    np.savez(filename,data = array.data ,indices=array.indices,
             indptr =array.indptr, shape=array.shape )

def load_sparse_csr(filename):
    loader = np.load(filename+".npz")
    return csr_matrix((  loader['data'], loader['indices'], loader['indptr']),
                         shape = loader['shape'])
def Make_2way(X):
    columns_length=X.shape[1]
    for j in range (columns_length):
        for d in range (j+1,columns_length):
            print("Adding column interaction: %d and %d" % (j, d))
            new_column = X[:,j] + X[:,d]
            X = scp.sparse.hstack((X,new_column), format="csr")
    return X

def interactionTermsAmazon(data, degree, hash=hash):
    new_data = []
    m,n = data.shape
    for indicies in itertools.combinations(range(n), degree):
        if not(5 in indicies and 7 in indicies) and not(2 in indicies and 3 in indicies):
            new_data.append([hash(tuple(v)) for v in data[:, indicies]])
    return np.array(new_data).T

def load_data(input_file):
    mydata = np.loadtxt(input_file,dtype=float)
    return mydata